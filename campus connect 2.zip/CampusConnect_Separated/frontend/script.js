const API_BASE = "http://localhost:5000/api";

async function loadEvents() {
    const container = document.getElementById("eventsContainer");
    const select = document.getElementById("eventName");
    if (!container && !select) return;

    try {
        const response = await fetch(`${API_BASE}/events`);
        if (!response.ok) throw new Error("Failed to load events");
        const events = await response.json();

        if (container) {
            renderEvents(events);
            window.allEvents = events;
        }

        if (select) {
            select.innerHTML = '<option value="">Choose an event</option>';
            events.forEach(event => {
                const option = document.createElement("option");
                option.value = event._id;
                option.textContent = event.title;
                select.appendChild(option);
            });
        }
    } catch (error) {
        console.error(error);
        if (container) {
            container.innerHTML = '<p class="empty-state">Backend is not connected. Start the server and refresh.</p>';
        }
    }
}

function renderEvents(events) {
    const container = document.getElementById("eventsContainer");
    const noEvents = document.getElementById("noEvents");
    if (!container) return;

    container.innerHTML = "";

    events.forEach(event => {
        const date = new Date(event.date);
        const month = date.toLocaleString("en-US", { month: "short" }).toUpperCase();
        const day = date.getDate();

        const card = document.createElement("div");
        card.className = "event-card event-item";
        card.dataset.category = event.category;

        card.innerHTML = `
            <div class="event-image ${event.category}">
                <span class="event-category">${event.category}</span>
                <span class="event-date">${month}<br><strong>${day}</strong></span>
            </div>
            <div class="event-info">
                <h3>${escapeHtml(event.title)}</h3>
                <p>${escapeHtml(event.description)}</p>
                <div class="event-bottom">
                    <span>📍 ${escapeHtml(event.location)}</span>
                    <a href="register.html?event=${encodeURIComponent(event._id)}">Register →</a>
                </div>
            </div>
        `;
        container.appendChild(card);
    });

    if (noEvents) noEvents.style.display = events.length ? "none" : "block";
}

function escapeHtml(value) {
    return String(value)
        .replaceAll("&", "&amp;")
        .replaceAll("<", "&lt;")
        .replaceAll(">", "&gt;")
        .replaceAll('"', "&quot;")
        .replaceAll("'", "&#039;");
}

function filterEvents() {
    const search = document.getElementById("searchInput");
    const category = document.getElementById("categoryFilter");
    if (!search || !category || !window.allEvents) return;

    const text = search.value.toLowerCase();
    const selected = category.value;

    const filtered = window.allEvents.filter(event => {
        const matchesText =
            event.title.toLowerCase().includes(text) ||
            event.description.toLowerCase().includes(text);

        const matchesCategory =
            selected === "all" || event.category === selected;

        return matchesText && matchesCategory;
    });

    renderEvents(filtered);
}

async function submitRegistration(event) {
    event.preventDefault();

    const token = localStorage.getItem("campusToken");

    const name = document.getElementById("name").value.trim();
    const studentId = document.getElementById("studentId").value.trim();
    const email = document.getElementById("email").value.trim();
    const password = document.getElementById("password").value;
    const eventId = document.getElementById("eventName").value;
    const department = document.getElementById("department").value;

    if (!eventId) {
        alert("Please select an event.");
        return;
    }

    try {
        let authToken = token;

        if (!authToken) {
            const registerResponse = await fetch(`${API_BASE}/auth/register`, {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({
                    name,
                    studentId,
                    email,
                    password,
                    department
                })
            });

            const registerData = await registerResponse.json();

            if (!registerResponse.ok) {
                throw new Error(registerData.message || "Registration failed");
            }

            authToken = registerData.token;
            localStorage.setItem("campusToken", authToken);
            localStorage.setItem("campusUser", JSON.stringify(registerData.user));
        }

        const eventResponse = await fetch(`${API_BASE}/events/register`, {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
                Authorization: `Bearer ${authToken}`
            },
            body: JSON.stringify({ eventId })
        });

        const eventData = await eventResponse.json();

        if (!eventResponse.ok) {
            throw new Error(eventData.message || "Event registration failed");
        }

        document.getElementById("successMessage").style.display = "flex";

        setTimeout(() => {
            window.location.href = "profile.html";
        }, 1200);

    } catch (error) {
        alert(error.message);
    }
}

async function loadProfile() {
    const list = document.getElementById("registrationList");
    if (!list) return;

    const token = localStorage.getItem("campusToken");
    const user = JSON.parse(localStorage.getItem("campusUser") || "null");

    if (!token) {
        list.innerHTML = '<p class="empty-state">Please register first to view your registrations.</p>';
        return;
    }

    if (user) {
        document.getElementById("profileName").textContent = user.name;
        document.getElementById("profileEmail").textContent = user.email;
        document.getElementById("profileId").textContent = user.studentId;
        document.getElementById("profileDepartment").textContent = user.department;
    }

    try {
        const response = await fetch(`${API_BASE}/events/my/registrations`, {
            headers: { Authorization: `Bearer ${token}` }
        });

        const registrations = await response.json();

        if (!response.ok) throw new Error(registrations.message);

        if (!registrations.length) {
            list.innerHTML = '<p class="empty-state">No event registrations yet.</p>';
            return;
        }

        list.innerHTML = registrations.map(item => {
            const event = item.event;
            const date = new Date(event.date).toLocaleDateString();

            return `
                <div class="registration-card">
                    <div class="registration-icon">🎟️</div>
                    <div class="registration-info">
                        <h3>${escapeHtml(event.title)}</h3>
                        <p>📅 Event date: ${date}</p>
                        <p>📍 ${escapeHtml(event.location)}</p>
                        <span class="status">${escapeHtml(item.status)}</span>
                    </div>
                </div>
            `;
        }).join("");

    } catch (error) {
        list.innerHTML = `<p class="empty-state">${escapeHtml(error.message)}</p>`;
    }
}

document.addEventListener("DOMContentLoaded", () => {
    loadEvents();

    const search = document.getElementById("searchInput");
    const category = document.getElementById("categoryFilter");
    if (search) search.addEventListener("input", filterEvents);
    if (category) category.addEventListener("change", filterEvents);

    const form = document.getElementById("registrationForm");
    if (form) form.addEventListener("submit", submitRegistration);

    const params = new URLSearchParams(window.location.search);
    const eventParam = params.get("event");

    if (eventParam) {
        setTimeout(() => {
            const select = document.getElementById("eventName");
            if (select) select.value = eventParam;
        }, 500);
    }

    loadProfile();
});


// Gentle reveal animation for sections as they enter the viewport.
(() => {
  const sections = document.querySelectorAll('.reveal');
  if (!('IntersectionObserver' in window) || !sections.length) return;
  sections.forEach(section => { section.style.opacity = '0'; section.style.transform = 'translateY(18px)'; section.style.transition = 'opacity .7s ease, transform .7s ease'; });
  const observer = new IntersectionObserver(entries => {
    entries.forEach(entry => {
      if (entry.isIntersecting) { entry.target.style.opacity = '1'; entry.target.style.transform = 'translateY(0)'; observer.unobserve(entry.target); }
    });
  }, { threshold: 0.12 });
  sections.forEach(section => observer.observe(section));
})();
