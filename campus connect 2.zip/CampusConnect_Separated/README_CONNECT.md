# CampusConnect — Enhanced Frontend + Backend

## Folders
- `frontend/`: HTML, CSS, JavaScript, animated UI and photo backgrounds.
- `backend/`: Express API, MongoDB models, authentication and event registration.

## Run locally
1. Make sure MongoDB is running locally, or use your MongoDB Atlas connection string.
2. Open a terminal and run `cd backend`.
3. Run `npm install`.
4. Copy `.env.example` to `.env`; set `MONGO_URI` and a long random `JWT_SECRET`.
5. Run `npm run seed` to add sample events.
6. Run `npm start`. Test `http://localhost:5000/api/health`.
7. Open `frontend/index.html` with VS Code Live Server.
8. `frontend/script.js` uses `http://localhost:5000/api` by default.

## Visuals
The refreshed frontend uses remote Unsplash photo URLs and Google Fonts, so internet access is needed for those images/fonts. Subtle animations respect reduced-motion settings.

## Deploy
Deploy `backend/` as a Node Web Service (build: `npm install`, start: `npm start`) and configure `MONGO_URI` and `JWT_SECRET` as environment variables. Deploy `frontend/` as a static site, then update `API_BASE` in `frontend/script.js` to `https://YOUR-BACKEND-URL/api`. Never upload your `.env` file to a public repository.
