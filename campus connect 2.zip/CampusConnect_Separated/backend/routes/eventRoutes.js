const express = require("express");
const {
    getEvents, getEvent, createEvent,
    registerForEvent, getMyRegistrations
} = require("../controllers/eventController");
const { protect, adminOnly } = require("../middleware/authMiddleware");

const router = express.Router();

router.get("/", getEvents);
router.get("/my/registrations", protect, getMyRegistrations);
router.get("/:id", getEvent);
router.post("/", protect, adminOnly, createEvent);
router.post("/register", protect, registerForEvent);

module.exports = router;
