require("dotenv").config();
const connectDB = require("./config/db");
const Event = require("./models/Event");

const events = [
    {
        title: "AAGMAN 2K26",
        description: "Music, Dance and Ramp Walk",
        category: "cultural",
        date: "2026-10-10",
        location: "College Auditorium",
        capacity: 500
    },
    {
        title: "Tech Innovation 2026",
        description: "Coding, AI and Innovation",
        category: "technology",
        date: "2026-10-18",
        location: "Computer Lab",
        capacity: 150
    },
    {
        title: "Campus Sports Fest",
        description: "Basketball, Football and Race",
        category: "sports",
        date: "2026-10-25",
        location: "College Ground",
        capacity: 300
    },
    {
        title: "Creative Design Workshop",
        description: "UI/UX, Graphic Design and Creative Ideas",
        category: "workshop",
        date: "2026-11-02",
        location: "Seminar Hall",
        capacity: 100
    },
    {
        title: "Web Development Bootcamp",
        description: "HTML, CSS and JavaScript",
        category: "technology",
        date: "2026-11-08",
        location: "Lab 2",
        capacity: 100
    },
    {
        title: "Campus Talent Hunt",
        description: "Singing, Dance and Performance",
        category: "cultural",
        date: "2026-11-15",
        location: "Open Stage",
        capacity: 200
    }
];

(async () => {
    try {
        await connectDB();
        await Event.deleteMany({});
        await Event.insertMany(events);
        console.log("Demo events inserted successfully.");
        process.exit(0);
    } catch (error) {
        console.error(error);
        process.exit(1);
    }
})();
