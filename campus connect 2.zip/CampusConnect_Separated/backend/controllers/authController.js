const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const User = require("../models/User");

const generateToken = user => jwt.sign(
    { id: user._id, role: user.role },
    process.env.JWT_SECRET,
    { expiresIn: "7d" }
);

const registerUser = async (req, res) => {
    try {
        const { name, email, password, studentId, department } = req.body;

        if (!name || !email || !password || !studentId || !department) {
            return res.status(400).json({ message: "All fields are required" });
        }

        const existing = await User.findOne({ $or: [{ email }, { studentId }] });
        if (existing) return res.status(400).json({ message: "Email or Student ID already exists" });

        const hashedPassword = await bcrypt.hash(password, 10);
        const user = await User.create({
            name, email, password: hashedPassword, studentId, department
        });

        res.status(201).json({
            message: "User registered successfully",
            token: generateToken(user),
            user: {
                id: user._id, name: user.name, email: user.email,
                studentId: user.studentId, department: user.department, role: user.role
            }
        });
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};

const loginUser = async (req, res) => {
    try {
        const { email, password } = req.body;
        const user = await User.findOne({ email });

        if (!user) return res.status(401).json({ message: "Invalid email or password" });

        const valid = await bcrypt.compare(password, user.password);
        if (!valid) return res.status(401).json({ message: "Invalid email or password" });

        res.json({
            message: "Login successful",
            token: generateToken(user),
            user: {
                id: user._id, name: user.name, email: user.email,
                studentId: user.studentId, department: user.department, role: user.role
            }
        });
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};

module.exports = { registerUser, loginUser };
