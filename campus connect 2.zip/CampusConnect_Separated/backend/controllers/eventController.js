const Event = require("../models/Event");
const Registration = require("../models/Registration");

const getEvents = async (req, res) => {
    try {
        const events = await Event.find().sort({ date: 1 });
        res.json(events);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};

const getEvent = async (req, res) => {
    try {
        const event = await Event.findById(req.params.id);
        if (!event) return res.status(404).json({ message: "Event not found" });
        res.json(event);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};

const createEvent = async (req, res) => {
    try {
        const event = await Event.create(req.body);
        res.status(201).json(event);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};

const registerForEvent = async (req, res) => {
    try {
        const { eventId } = req.body;
        const event = await Event.findById(eventId);

        if (!event) return res.status(404).json({ message: "Event not found" });

        const existing = await Registration.findOne({
            student: req.user.id, event: eventId
        });

        if (existing) {
            return res.status(400).json({ message: "You are already registered for this event" });
        }

        const registration = await Registration.create({
            student: req.user.id, event: eventId
        });

        res.status(201).json({
            message: "Event registration successful",
            registration
        });
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};

const getMyRegistrations = async (req, res) => {
    try {
        const registrations = await Registration.find({ student: req.user.id })
            .populate("event")
            .sort({ createdAt: -1 });

        res.json(registrations);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};

module.exports = {
    getEvents, getEvent, createEvent,
    registerForEvent, getMyRegistrations
};
