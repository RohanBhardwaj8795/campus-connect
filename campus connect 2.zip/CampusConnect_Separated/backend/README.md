# CampusConnect Backend

## Local setup

1. Install Node.js and MongoDB.
2. Open this folder in VS Code.
3. Run:
   npm install
4. Copy `.env.example` to `.env`.
5. Make sure MongoDB is running.
6. Seed demo events:
   npm run seed
7. Start:
   npm run dev

API:
GET /api/health
POST /api/auth/register
POST /api/auth/login
GET /api/events
GET /api/events/:id
POST /api/events/register
GET /api/events/my/registrations

For production deployment, use MongoDB Atlas (or another hosted MongoDB provider) and set MONGO_URI and JWT_SECRET in the deployment environment.
