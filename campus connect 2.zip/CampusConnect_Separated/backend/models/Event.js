const mongoose = require("mongoose");

const eventSchema = new mongoose.Schema({
    title: { type: String, required: true },
    description: { type: String, required: true },
    category: {
        type: String,
        required: true,
        enum: ["cultural", "technology", "sports", "workshop"]
    },
    date: { type: Date, required: true },
    location: { type: String, required: true },
    capacity: { type: Number, default: 100 }
}, { timestamps: true });

module.exports = mongoose.model("Event", eventSchema);
